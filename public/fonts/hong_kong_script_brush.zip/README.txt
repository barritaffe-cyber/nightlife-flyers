THIS FONT IS FREE FOR PERSONAL USE...
Commercial license font are available there :
thomasaradea@gmail.com


DOWNLOAD FULLVERSION IN MY STORE:
https://letterarastudio.com/product/hongkong/


Paypal Accoun for donation (support me): 
https://www.paypal.me/thomasaradea


INDONESIA � MOHON DIBACA:
Halo, buat agency, designer, youtuber, atau siapa saja yang akan menggunakan font ini untuk kebutuhan KOMERSIL, seperti poster film, pamphlet, promo, logo perusahaan, kaos, dan sejenisnya bisa langsung membeli licensinya disaya. Silahkan menghubungi Instagram saya/ email
Tenang, harga bersahabat kok.
terimakasih